$(document).ready(function(){
  $(".owl-carousel").owlCarousel({
      loop: true,
      nav: true,
      margin: 10,
      items: 1,
      autoHeight: true
  });
});
