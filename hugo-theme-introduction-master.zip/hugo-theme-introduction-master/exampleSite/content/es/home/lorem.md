---
title: "Lorem Ipsum"
weight: 30
---

You can add more sections to the home page by adding file to `content/home/`
