---
title: "Contacto"
---

En la sección de Contacto de **Introducción**, tu puedes opcionalmente mostrar la hora actual en tu zona horaria preferida.

Esto permite a los visitantes saber que tiempo de respuesta esperan tener cuando te contactan. La zhoa horaria es facilmente configurable en el archivo de configuración.
