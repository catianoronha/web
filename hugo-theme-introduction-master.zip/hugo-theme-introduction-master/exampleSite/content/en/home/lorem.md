---
title: "Lorem Ipsum"
weight: 30
---

You can add more sections to the home page by adding files to the `/content/home/` folder.
